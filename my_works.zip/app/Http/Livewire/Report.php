<?php

namespace App\Http\Livewire;

use App\Models\MyWork;
use Livewire\Component;
use Livewire\WithPagination;

class Report extends Component
{
    use WithPagination;
    public $show_task_details=false;
    public $task_id;

    public function taskDetails($id)
    {
        $this->task_id = $id;
        $this->show_task_details = true;
    }
    public function render()
    {
        return view('livewire.report',[
            'completed_tasks' => MyWork::where('user_id','=',auth()->id())->where('status','=','completed')->get()
        ]);
    }
}
