﻿$(document).ready(function () {
    /*$('.sidenav').sidenav();*/
    $('.collapsible').collapsible();
    $('.dropdown-trigger').dropdown({
        constrainWidth: false,
        coverTrigger: false
    });
    $('.datepicker').datepicker({
        format: 'mm/dd/yyyy',
        autoClose: true,
        container: 'body'
    });
    /*
    $('.modal').modal({
        preventScrolling: false
    });
    $('select').formSelect();
    $('.carousel').carousel();
    $('.timepicker').timepicker();
    $('.tooltipped').tooltip();*/
});
