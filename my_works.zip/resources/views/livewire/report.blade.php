<div>
    <x-layout title="My tasks report" active="index">
        <nav class="pl-5 breadcrumb-nav grey lighten-4 z-depth-0 border-bottom" style="z-index:1">
            <div class="nav-wrapper">
                <div class="col s12">
                    <a href="{{route('index')}}" class="breadcrumb black-text">Home</a>
                    <a href="javascript:void(0)" style="cursor:text" class="breadcrumb disabled">Report</a>
                </div>
            </div>
        </nav>
        <div class="row mx-2">
            <div class="col s12">
                <h5 class="d-inline-block">
                    My tasks report
                </h5>
                <br /><br />
                <x-datatable :buttons="true" id="table1" :hide="true">
                    <thead>
                    <tr>
                        <td>No</td>
                        <td>Title</td>
                        <td>Year</td>
                        <td>Month</td>
                        <td>Day</td>
                        <td>Start Date</td>
                        <td>End Date</td>
                        <td>Details</td>
                    </tr>
                    </thead>
                    <tbody>
                    @php $i=1; @endphp
                    @foreach($completed_tasks as $task)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{$task->title}}</td>
                            <td>{{$task->year}}</td>
                            <td>
                                @php
                                    $dateObj   = DateTime::createFromFormat('!m', $task->month);
                                    echo $monthName = $dateObj->format('F');
                                @endphp
                            </td>
                            <td>{{$task->day}}</td>
                            <td>{{$task->start_date}}</td>
                            <td>{{$task->expire_date}}</td>
                            <td>
                                <button x-data @click="$(event.target).html(aem.spinner())" wire:click="taskDetails('{{$task->id}}')">
                                    Details
                                </button>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </x-datatable>
            </div>
        </div>
        @if($show_task_details)
            <x-modal style="height: 100%;width: 90%;">
                @livewire('my-work-details',['id'=>$task_id],key($task_id))
            </x-modal>
        @endif
    </x-layout>
</div>
@include('inc.scripts',['datatable'=>true,'buttons'=>true])
