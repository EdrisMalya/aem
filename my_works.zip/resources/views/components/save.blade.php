<button type="submit" class="btn waves-effect transparent green-text btn-small" {{$attributes}} wire:loading.attr="disabled">
    {{$slot}} <i class="material-icons right green-text">save</i>
</button>
