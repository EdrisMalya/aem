<div>
    <?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, ['title' => 'index','active' => 'user.index']); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <nav class="pl-5 breadcrumb-nav grey lighten-4 z-depth-0 border-bottom" style="z-index:1">
            <div class="nav-wrapper">
                <div class="col s12">
                    <a href="<?php echo e(route('index')); ?>" class="breadcrumb black-text">Home</a>
                    <a href="javascript:void(0)" style="cursor:text" class="breadcrumb disabled">Users</a>
                </div>
            </div>
        </nav>
        <div class="row mx-2">
            <div class="col s12">
                <h5 class="d-inline-block">
                    List of categories
                </h5>
                <?php if(auth()->user()->allow('v','Users',['CreateUser'])): ?>
                <a data-turbolink="false" href="<?php echo e(route('user')); ?>" class="btn waves-effect transparent black-text mt-3 right">Add new user <i class="material-icons right">add</i></a>
                <?php endif; ?>
                <br /><br />
                <?php if (isset($component)) { $__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Datatable::class, ['buttons' => true]); ?>
<?php $component->withName('datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'table1']); ?>
                    <thead>
                    <tr>
                        <th>No#</th>
                        <th>Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->last_name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->role!=null?$user->role->name:'Root Admin'); ?></td>
                                <td>
                                    <?php if(auth()->user()->allow('v','Users',['EditUser'])): ?>
                                    <a href="<?php echo e(route('user',$user)); ?>">
                                        <i class="material-icons tiny orange-text">edit</i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->allow('v','Users',['DeleteUser'])): ?>
                                    <a class="c-pointer" wire:click="deleteForm('<?php echo e($user->id); ?>')">
                                        <i class="material-icons tiny red-text">delete</i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                 <?php if (isset($__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a)): ?>
<?php $component = $__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a; ?>
<?php unset($__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        </div>
        <?php if($showDelete): ?>
            <div id="modal" class="modal" x-data x-init="$('.modal').modal({dismissible:false}); M.Modal.getInstance($('#modal')).open()">
                <div class="modal-content">
                    <h4>Delete Row </h4>
                    <p>Are you sure to delete this row?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="modal-action modal-close waves-effect waves-red btn-flat ">Cancel</button>
                    <button wire:click="delete" wire:loading.attr="disabled" class="modal-action waves-effect waves-green btn-flat ">Yes</button>
                </div>
            </div>
        <?php endif; ?>
     <?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>
<?php echo $__env->make('inc.scripts',['datatable'=>true,'buttons'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\projects\my_works\resources\views/livewire/user/index.blade.php ENDPATH**/ ?>