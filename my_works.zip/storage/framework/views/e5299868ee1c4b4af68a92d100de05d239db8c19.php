<div wire:ignore>
    <label for="role"><b><?php echo e(ucfirst(str_replace(['id','_','-'],['','',''],strtolower($name)))); ?></b></label>
    <select placeholder="<?php echo e($placeholder); ?>" <?php echo e($attributes); ?> class="browser-default" x-data="" x-ref="<?php echo e($name); ?>" x-init="()=>{
            setTimeout(()=>{
                $($refs.<?php echo e($name); ?>).selectize();
            },100);
        }" wire:model="<?php echo e($name); ?>" onchange="window.livewire.find('<?php echo e($_instance->id); ?>').set('<?php echo e($name); ?>',$(event.target).val())" id="<?php echo e($name); ?>">
        <option value="" selected></option>
        <?php echo e($slot); ?>

    </select>
</div>
<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<blockquote><?php echo e($message); ?></blockquote>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php /**PATH D:\projects\my_works\resources\views/components/select.blade.php ENDPATH**/ ?>