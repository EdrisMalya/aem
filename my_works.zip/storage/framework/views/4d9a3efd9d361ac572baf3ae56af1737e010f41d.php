<button  type="button" class="btn waves-effect modal-close transparent red-text btn-small" <?php echo e($attributes); ?> x-data @click="$(event.target).html(aem.spinner()).prop('disabled',true)">
    <?php echo e($slot); ?> <i class="material-icons right red-text">close</i>
</button>
<?php /**PATH D:\projects\my_works\resources\views/components/cancel.blade.php ENDPATH**/ ?>