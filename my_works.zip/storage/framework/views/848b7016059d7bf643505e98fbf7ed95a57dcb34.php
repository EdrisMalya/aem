 <?php $__env->slot('title'); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
<nav style="height:60px; position:fixed; z-index:999;" class="white black-text z-depth-1">
    <div style="height:100%; line-height:60px;" class="px-3 blue d-inline-block left waves-effect" onclick="aem.collapseSidebar()">
        <i class="material-icons white-text large">menu</i>
        <input type="checkbox" id="mobile-mode" />
    </div>
    <ul class="left ml-3">
        <li>
            <h5 style="font-weight:bolder" id="min-title">
                <?php echo e(ucfirst(implode(' ',explode('-',\Illuminate\Support\Str::kebab(env('app_name')))))); ?>

            </h5>
        </li>
    </ul>
    <ul class="right">
        <li class="px-3">
            <a href="#dropdown1"  class="black-text browser-default waves-effect waves-block dropdown-trigger">
                <div style="display:flex; flex-direction:row" class="mr-4">
                    <span class="profile-avatar mt-2">
                        <?php if(auth()->user()->profile != null): ?>
                            <img width="100%" src="<?php echo e(asset('storage/'.auth()->user()->profile)); ?>" class="profile-user-img" />
                        <?php else: ?>
                            <img width="100%" src="<?php echo e(asset('img/user.png')); ?>" class="profile-user-img"/>
                        <?php endif; ?>
                    </span>
                    <div class="ml-3">
                        <?php echo e(auth()->user()->name); ?>

                        <?php echo e(auth()->user()->last_name); ?>

                        <i class="material-icons right mt-1">arrow_drop_down</i>
                    </div>
                </div>
            </a>
            <ul id='dropdown1' class='dropdown-content'>
                <li>
                    <a class="black-text" href="<?php echo e(route('profile')); ?>">
                        <i class="material-icons left">person_outline</i>
                    Profile
                    </a>
                </li>
                <li class="divider" tabindex="-1"></li>
                <li>
                    <a class="black-text" href="javascript:document.getElementById('logoutForm').submit()">Logout</a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<form action="<?php echo e(route('logout')); ?>" id="logoutForm" method="post">
    <?php echo csrf_field(); ?>
</form>
<?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content" <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</div>
<?php if(session()->has('message')): ?>
    <script>
        M.toast({
            html: '<?php echo e(session()->get('message')); ?>',
            classes: '<?php echo e(session()->has('classes')?session()->get('classes'):'green rounded'); ?>'
        });
    </script>
<?php endif; ?>
<?php if(isset($js)): ?>
     <?php $__env->slot('js'); ?> 
        <?php echo e($js); ?>

     <?php $__env->endSlot(); ?>
<?php endif; ?>
<?php if(isset($css)): ?>
     <?php $__env->slot('css'); ?> 
        <?php echo e($css); ?>

     <?php $__env->endSlot(); ?>
<?php endif; ?>
<?php /**PATH D:\projects\my_works\resources\views/layouts/layout.blade.php ENDPATH**/ ?>