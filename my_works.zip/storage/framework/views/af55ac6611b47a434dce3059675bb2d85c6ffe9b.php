<div>
    <?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, ['title' => 'My tasks report','active' => 'index']); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <nav class="pl-5 breadcrumb-nav grey lighten-4 z-depth-0 border-bottom" style="z-index:1">
            <div class="nav-wrapper">
                <div class="col s12">
                    <a href="<?php echo e(route('index')); ?>" class="breadcrumb black-text">Home</a>
                    <a href="javascript:void(0)" style="cursor:text" class="breadcrumb disabled">Report</a>
                </div>
            </div>
        </nav>
        <div class="row mx-2">
            <div class="col s12">
                <h5 class="d-inline-block">
                    My tasks report
                </h5>
                <br /><br />
                <?php if (isset($component)) { $__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Datatable::class, ['buttons' => true]); ?>
<?php $component->withName('datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'table1','hide' => true]); ?>
                    <thead>
                    <tr>
                        <td>No</td>
                        <td>Title</td>
                        <td>Year</td>
                        <td>Month</td>
                        <td>Day</td>
                        <td>Start Date</td>
                        <td>End Date</td>
                        <td>Details</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $completed_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($task->title); ?></td>
                            <td><?php echo e($task->year); ?></td>
                            <td>
                                <?php
                                    $dateObj   = DateTime::createFromFormat('!m', $task->month);
                                    echo $monthName = $dateObj->format('F');
                                ?>
                            </td>
                            <td><?php echo e($task->day); ?></td>
                            <td><?php echo e($task->start_date); ?></td>
                            <td><?php echo e($task->expire_date); ?></td>
                            <td>
                                <button x-data @click="$(event.target).html(aem.spinner())" wire:click="taskDetails('<?php echo e($task->id); ?>')">
                                    Details
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                 <?php if (isset($__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a)): ?>
<?php $component = $__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a; ?>
<?php unset($__componentOriginal1235f0f62ac1d5d5c5333e995ffb9ce3c5336a9a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        </div>
        <?php if($show_task_details): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => ['style' => 'height: 100%;width: 90%;']]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['style' => 'height: 100%;width: 90%;']); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-work-details',['id'=>$task_id])->html();
} elseif ($_instance->childHasBeenRendered($task_id)) {
    $componentId = $_instance->getRenderedChildComponentId($task_id);
    $componentTag = $_instance->getRenderedChildComponentTagName($task_id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($task_id);
} else {
    $response = \Livewire\Livewire::mount('my-work-details',['id'=>$task_id]);
    $html = $response->html();
    $_instance->logRenderedChild($task_id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>
<?php echo $__env->make('inc.scripts',['datatable'=>true,'buttons'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\projects\my_works\resources\views/livewire/report.blade.php ENDPATH**/ ?>