<div>
    <?php if($tasks->count() < 1): ?>
        <p class="center red-text my-5">No record found</p>
    <?php else: ?>
        <div class="row mt-3">
            <div class="col s12 m4 border-right">
                <p>
                    <b>Upcoming</b>
                </p>
                <?php if($upcoming_tasks->count() > 0): ?>
                    <ol class="browser-default">
                        <?php $__currentLoopData = $upcoming_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mt-2">
                                    <span class="d-inline-block">
                                        <?php echo e($u_task->title); ?>

                                        <br>
                                    </span>
                                <small>
                                    <?php if($u_task->from_user_id!=0): ?>
                                        <span class="red-text">
                                            | Assigned From: <b><?php echo e(\App\Models\User::find($u_task->from_user_id)->name); ?> <?php echo e(\App\Models\User::find($u_task->from_user_id)->last_name); ?></b>
                                        </span>
                                    <?php endif; ?>
                                </small>
                                <button class="right mr-0" wire:click="taskDetails('<?php echo e($u_task->id); ?>')">Details</button>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                <?php else: ?>
                    <p class="red-text center mt-3">No record found</p>
                <?php endif; ?>
            </div>
            <div class="col s12 m4 border-right">
                <p>
                    <b>Running</b>
                </p>
                <?php if($running_tasks->count() > 0): ?>
                    <ol class="browser-default">
                        <?php $__currentLoopData = $running_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mt-2">
                                    <span class="d-inline-block">
                                        <?php echo e($r_task->title); ?>

                                        <br>
                                    </span>
                                <small>
                                    <?php if($r_task->from_user_id!=0): ?>
                                        <span class="red-text">
                                            | Assigned From: <b><?php echo e(\App\Models\User::find($r_task->from_user_id)->name); ?> <?php echo e(\App\Models\User::find($r_task->from_user_id)->last_name); ?></b>
                                        </span>
                                    <?php endif; ?>
                                </small>
                                <button class="right mr-0" wire:click="taskDetails('<?php echo e($r_task->id); ?>')">Details</button>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                <?php else: ?>
                    <p class="red-text center mt-3">No record found</p>
                <?php endif; ?>
            </div>
            <div class="col s12 m4 border-right">
                <p>
                    <b>Completed</b>
                </p>
                <?php if($completed_tasks->count() > 0): ?>
                    <ol class="browser-default">
                        <?php $__currentLoopData = $completed_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mt-2">
                                    <span class="d-inline-block">
                                        <?php echo e($r_task->title); ?>

                                        <br>
                                    </span>
                                <small>
                                    <?php if($r_task->from_user_id!=0): ?>
                                        <span class="red-text">
                                            | Assigned From: <b><?php echo e(\App\Models\User::find($r_task->from_user_id)->name); ?> <?php echo e(\App\Models\User::find($r_task->from_user_id)->last_name); ?></b>
                                        </span>
                                    <?php endif; ?>
                                </small>
                                <button class="right mr-0" wire:click="taskDetails('<?php echo e($r_task->id); ?>')">Details</button>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                    <?php if($user_id==auth()->id()): ?>
                        <a href="<?php echo e(route('report')); ?>" class="btn waves-effect transparent black-text btn-small">
                            generate report
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="red-text center mt-3">No record found</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
    <?php if($task_details): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => ['style' => 'height: 100%;width: 90%;']]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['style' => 'height: 100%;width: 90%;']); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-work-details',['id'=>$task->id])->html();
} elseif ($_instance->childHasBeenRendered($task->id)) {
    $componentId = $_instance->getRenderedChildComponentId($task->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($task->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($task->id);
} else {
    $response = \Livewire\Livewire::mount('my-work-details',['id'=>$task->id]);
    $html = $response->html();
    $_instance->logRenderedChild($task->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if($deleteModel): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => ['class' => 'modal-fixed-footer']]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'modal-fixed-footer']); ?>
            <div class="modal-content">
                <h4>Delete Row </h4>
                <p>Are you sure to delete this row?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-action modal-close waves-effect waves-red btn-flat ">Cancel</button>
                <button wire:click="delete" wire:loading.attr="disabled" class="modal-action waves-effect waves-green btn-flat ">Yes</button>
            </div>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH D:\projects\my_works\resources\views/livewire/my-tasks.blade.php ENDPATH**/ ?>