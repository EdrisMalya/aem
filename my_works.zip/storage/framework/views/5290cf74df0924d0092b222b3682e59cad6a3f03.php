<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link href="<?php echo e(asset('plugins/materialize/materialize.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-helper.css')); ?>">
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/selectize/selectize.min.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->yieldPushContent('css'); ?>
    <?php echo e($css??''); ?>

</head>
<body>
    <div id="wait_for_response" style="display: none"></div>
    <?php echo e($slot); ?>

    <title><?php echo e($title ?? config('app.name', 'Laravel')); ?></title>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('alpine.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/livewire-turbolinks.js')); ?>" data-turbolinks-eval="false" data-turbo-eval="false"></script>
    <script src="<?php echo e(asset('plugins/materialize/materialize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/selectize/selectize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('init.js')); ?>"></script>
    <script src="<?php echo e(asset('js.js')); ?>"></script>
    <?php echo e($js??''); ?>

    <?php echo $__env->yieldPushContent('js'); ?>
    <?php if(session()->has('message')): ?>
        <script>
            M.toast({
                html: '<?php echo e(session()->get('message')); ?>',
                classes: '<?php echo e(session()->has('classes')?session()->get('classes'):'green rounded'); ?>'
            });
        </script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\projects\my_works\resources\views/layouts/app.blade.php ENDPATH**/ ?>