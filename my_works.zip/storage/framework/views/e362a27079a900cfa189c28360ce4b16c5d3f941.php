<?php $id = uniqid(); ?>
<div id="modal<?php echo e($id); ?>" <?php echo e($attributes); ?> <?php echo e($attributes->merge(['class'=>'modal'])); ?> x-data x-init="$('.modal').modal({dismissible:false}); M.Modal.getInstance($('#modal<?php echo e($id); ?>')).open()">
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\projects\my_works\resources\views/components/modal.blade.php ENDPATH**/ ?>