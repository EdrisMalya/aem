<button type="submit" class="btn waves-effect transparent green-text btn-small" <?php echo e($attributes); ?> wire:loading.attr="disabled">
    <?php echo e($slot); ?> <i class="material-icons right green-text">save</i>
</button>
<?php /**PATH D:\projects\my_works\resources\views/components/save.blade.php ENDPATH**/ ?>