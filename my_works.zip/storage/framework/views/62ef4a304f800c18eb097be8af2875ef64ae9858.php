<button <?php echo e($attributes->merge(['class'=>'btn black-text waves-effect transparent'])); ?> <?php echo e($attributes); ?> x-data @click="$(event.target).html(aem.spinner()).prop('disabled',true)">
    <?php echo e($slot); ?>

</button>
<?php /**PATH D:\projects\my_works\resources\views/components/button.blade.php ENDPATH**/ ?>