<div>
    <?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, ['active' => 'index','title' => 'Home']); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <nav class="pl-5 breadcrumb-nav grey lighten-4 z-depth-0 border-bottom" style="z-index:1">
            <div class="nav-wrapper">
                <div class="col s12">
                    <a href="<?php echo e(route('index')); ?>" class="breadcrumb black-text">Home</a>
                    <a href="javascript:void(0)" style="cursor:text" class="breadcrumb disabled">My works</a>
                </div>
            </div>
        </nav>
        <div class="row mx-2">
            <div class="col s12">
                <h5 class="d-inline-block">
                    My works
                </h5>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:click' => '$set(\'form\',true)','class' => 'mt-3 right']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$set(\'form\',true)','class' => 'mt-3 right']); ?>
                    Add task for me <i class="material-icons right">add</i>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if(auth()->user()->user_id==0): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'right mt-3','wire:click' => '$set(\'assignTask\',true)']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'right mt-3','wire:click' => '$set(\'assignTask\',true)']); ?>
                        Add task for employees <i class="material-icons right">add</i>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->user()->user_id==0): ?>
                    <div class="row">
                        <div class="col s12">
                            <ul class="collapsible popout">
                                <li>
                                    <div class="collapsible-header">
                                        <i class="material-icons">filter_list</i>
                                        List of my works
                                    </div>
                                    <div class="collapsible-body">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-tasks',['user_id' => auth()->id()])->html();
} elseif ($_instance->childHasBeenRendered('liXydum')) {
    $componentId = $_instance->getRenderedChildComponentId('liXydum');
    $componentTag = $_instance->getRenderedChildComponentTagName('liXydum');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('liXydum');
} else {
    $response = \Livewire\Livewire::mount('my-tasks',['user_id' => auth()->id()]);
    $html = $response->html();
    $_instance->logRenderedChild('liXydum', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </li>
                                <li>
                                    <div class="collapsible-header">
                                        <i class="material-icons">people</i>
                                        List of my employee works
                                    </div>
                                    <div class="collapsible-body">
                                        <?php if($users->count() < 1): ?>
                                            <p class="center red-text my-5">No employee found</p>
                                        <?php else: ?>
                                            <ul class="collapsible">
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <div class="collapsible-header">
                                                            <a href="<?php echo e(asset('storage/'.$employee->profile)); ?>" target="_blank">
                                                                <img src="<?php echo e(asset('storage/'.$employee->profile)); ?>" height="40px;" alt="">
                                                            </a>
                                                            <span class="d-inline-block mt-3 ml-2 pl-3">
                                                                <?php echo e($employee->name); ?>

                                                                <?php echo e($employee->last_name); ?>

                                                            </span>
                                                        </div>
                                                        <div class="collapsible-body">
                                                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-tasks',['user_id' => $employee->id])->html();
} elseif ($_instance->childHasBeenRendered($employee->id)) {
    $componentId = $_instance->getRenderedChildComponentId($employee->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($employee->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($employee->id);
} else {
    $response = \Livewire\Livewire::mount('my-tasks',['user_id' => $employee->id]);
    $html = $response->html();
    $_instance->logRenderedChild($employee->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                                        </div>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                        
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                <?php else: ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-tasks',['user_id' => auth()->id()])->html();
} elseif ($_instance->childHasBeenRendered('YXoazxE')) {
    $componentId = $_instance->getRenderedChildComponentId('YXoazxE');
    $componentTag = $_instance->getRenderedChildComponentTagName('YXoazxE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YXoazxE');
} else {
    $response = \Livewire\Livewire::mount('my-tasks',['user_id' => auth()->id()]);
    $html = $response->html();
    $_instance->logRenderedChild('YXoazxE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endif; ?>
            </div>
        </div>
        <?php if($form): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('task-form')->html();
} elseif ($_instance->childHasBeenRendered('1e4TDZZ')) {
    $componentId = $_instance->getRenderedChildComponentId('1e4TDZZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('1e4TDZZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1e4TDZZ');
} else {
    $response = \Livewire\Livewire::mount('task-form');
    $html = $response->html();
    $_instance->logRenderedChild('1e4TDZZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if($assignTask): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('assing-task')->html();
} elseif ($_instance->childHasBeenRendered('sMmJNtf')) {
    $componentId = $_instance->getRenderedChildComponentId('sMmJNtf');
    $componentTag = $_instance->getRenderedChildComponentTagName('sMmJNtf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sMmJNtf');
} else {
    $response = \Livewire\Livewire::mount('assing-task');
    $html = $response->html();
    $_instance->logRenderedChild('sMmJNtf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php echo $__env->make('inc.scripts',['ckeditor'=>true,'filepond'=>true,'sweetalert'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH D:\projects\my_works\resources\views/livewire/home.blade.php ENDPATH**/ ?>