<div>
    <div class="modal-content">
        <?php if($parent_task!=null): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn-floating','wire:click' => 'previousTask']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn-floating','wire:click' => 'previousTask']); ?>
                <i class="material-icons">keyboard_arrow_left</i>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
        <h5>
            <?php echo e($task->title); ?>

        </h5>
        <?php if($task->user_id == auth()->id()): ?>
            <span class="grey-text">
                <b>
                    Status:
                </b>
                <?php echo e($task->status); ?><br><br>
                <?php if($task->status=='upcoming'): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => 'moveToRunning']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => 'moveToRunning']); ?>
                Move to running
                <i class="material-icons right">arrow_forward</i>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php elseif($task->status=='running'): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => 'moveToUpcoming']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => 'moveToUpcoming']); ?>
                    Move to Upcoming
                    <i class="material-icons right">arrow_back</i>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => 'moveToCompleted']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => 'moveToCompleted']); ?>
                    Move to Completed
                    <i class="material-icons right">arrow_forward</i>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php elseif($task->status=='completed'): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => 'moveToRunning']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => 'moveToRunning']); ?>
                    Move to Running
                    <i class="material-icons left">arrow_back</i>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => '$set(\'showDeleteModal\',true)']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => '$set(\'showDeleteModal\',true)']); ?>
                    <span class="red-text">Delete</span>
                    <i class="material-icons right red-text">delete</i>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => '$toggle(\'edit_mode\')']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => '$toggle(\'edit_mode\')']); ?>
                    <span class="orange-text">Edit</span>
                    <i class="material-icons right orange-text">edit</i>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </span>
        <?php endif; ?>
        <p>
            <b>Description</b>
        </p>
        <?php if($edit_mode): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.editor','data' => ['name' => 'description','value' => $task->description]]); ?>
<?php $component->withName('editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'description','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task->description)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => 'saveDescription']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => 'saveDescription']); ?>
                    <span class="green-text">
                        Save
                        <i class="material-icons right">save</i>
                    </span>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php else: ?>
            <?php echo $task->description; ?>

        <?php endif; ?>
        <?php if($task->files->count() > 0): ?>
            <table>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Size</th>
                    <th>Extension</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $task->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(asset('storage/'.$file->file)); ?>">
                                <?php echo e($file->file_name); ?>

                            </a>
                        </td>
                        <td><?php echo e($file->file_size); ?></td>
                        <td><?php echo e($file->file_ext); ?></td>
                        <td>
                            <?php if($edit_mode): ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['wire:loading.attr' => 'disabled','wire:click' => 'deleteFile(\''.e($file->id).'\')']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:click' => 'deleteFile(\''.e($file->id).'\')']); ?>
                                    <i class="material-icons red-text">delete</i>
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <?php if($edit_mode): ?>
            <p>
                <b>Upload File</b>
            </p>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.filepond','data' => ['name' => 'files','multiple' => 'true']]); ?>
<?php $component->withName('filepond'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'files','multiple' => 'true']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['id' => 'save','wire:loading.attr' => 'disabled','wire:click' => 'saveFiles(\''.e($task->id).'\')']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'save','wire:loading.attr' => 'disabled','wire:click' => 'saveFiles(\''.e($task->id).'\')']); ?>
                <span class="green-text">
                    Save
                    <i class="material-icons right">save</i>
                </span>
             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
        <div class="col s12">
            <ul class="collapsible" x-data x-init="$('.collapsible').collapsible();">
                <li>
                    <div class="collapsible-header"><i class="material-icons">filter_list</i>Sub tasks</div>
                    <div class="collapsible-body">
                        <?php if($task->tasks->count() < 1): ?>
                            <p class="center red-text my-4">No sub tasks found</p>
                        <?php else: ?>
                            <div class="row mt-3">
                                <div class="col s12 m4 border-right">
                                    <p>
                                        <b>Upcoming</b>
                                    </p>
                                    <?php if($task->tasks->where('status','=','upcoming')->count() > 0): ?>
                                        <ol class="browser-default">
                                            <?php $__currentLoopData = $task->tasks->where('status','=','upcoming'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php echo e($u_task->title); ?>

                                                    <button class="right" wire:click="taskDetails('<?php echo e($u_task->id); ?>','<?php echo e($task->id); ?>')">Details</button>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    <?php else: ?>
                                        <p class="red-text center mt-3">No record found</p>
                                    <?php endif; ?>
                                </div>
                                <div class="col s12 m4 border-right">
                                    <p>
                                        <b>Running</b>
                                    </p>
                                    <?php if($task->tasks->where('status','=','running')->count() > 0): ?>
                                        <ol class="browser-default">
                                            <?php $__currentLoopData = $task->tasks->where('status','=','running'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php echo e($r_task->title); ?>

                                                    <span class="right border-bottom blue-text c-pointer" wire:click="taskDetails('<?php echo e($r_task->id); ?>','<?php echo e($task->id); ?>')">Details</span>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    <?php else: ?>
                                        <p class="red-text center mt-3">No record found</p>
                                    <?php endif; ?>
                                </div>
                                <div class="col s12 m4 border-right">
                                    <p>
                                        <b>Completed</b>
                                    </p>
                                    <?php if($task->tasks->where('status','=','completed')->count() > 0): ?>
                                        <ol class="browser-default">
                                            <?php $__currentLoopData = $task->tasks->where('status','=','completed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php echo e($c_task->title); ?>

                                                    <span class="right border-bottom blue-text c-pointer" wire:click="taskDetails('<?php echo e($c_task->id); ?>','<?php echo e($task->id); ?>')">Details</span>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                    <?php else: ?>
                                        <p class="red-text center mt-3">No record found</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn-floating','wire:click' => '$set(\'addSubTask\',true)']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn-floating','wire:click' => '$set(\'addSubTask\',true)']); ?>
                            <i class="material-icons">add</i>
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                </li>
            </ul>
            <?php if($addSubTask): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('task-form',['user_id' => $user_id, 'task_id' => $task->id])->html();
} elseif ($_instance->childHasBeenRendered(time())) {
    $componentId = $_instance->getRenderedChildComponentId(time());
    $componentTag = $_instance->getRenderedChildComponentTagName(time());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(time());
} else {
    $response = \Livewire\Livewire::mount('task-form',['user_id' => $user_id, 'task_id' => $task->id]);
    $html = $response->html();
    $_instance->logRenderedChild(time(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endif; ?>
        </div>
    </div>
    <div class="modal-footer">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cancel','data' => ['wire:click' => 'closeForm']]); ?>
<?php $component->withName('cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'closeForm']); ?>
            Close
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <?php if($showDeleteModal): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.confirmation','data' => ['deleteAction' => 'delete','closeAction' => 'set(\'showDeleteModal\',false)']]); ?>
<?php $component->withName('confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['deleteAction' => 'delete','closeAction' => 'set(\'showDeleteModal\',false)']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if($showFileDeleteModal): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.confirmation','data' => ['deleteAction' => 'deleteFileAction(\''.e($task->id).'\')','closeAction' => 'set(\'showFileDeleteModal\',false)']]); ?>
<?php $component->withName('confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['deleteAction' => 'deleteFileAction(\''.e($task->id).'\')','closeAction' => 'set(\'showFileDeleteModal\',false)']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH D:\projects\my_works\resources\views/livewire/my-work-details.blade.php ENDPATH**/ ?>