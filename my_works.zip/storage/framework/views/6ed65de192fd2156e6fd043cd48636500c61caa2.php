<?php if(isset($datatable) and $datatable==true): ?>
    <?php $__env->startPush('css'); ?>
        <link href="<?php echo e(asset('plugins/datatable/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('plugins/datatable/css/responsive.dataTables.min.css')); ?>" rel="stylesheet" />
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/datatable/js/dataTables.responsive.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
    <?php if(isset($buttons) and $buttons==true): ?>
        <?php $__env->startPush('css'); ?>
            <link href="<?php echo e(asset('plugins/datatable/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
            <link href="<?php echo e(asset('plugins/datatable/css/responsive.dataTables.min.css')); ?>" rel="stylesheet" />
            <link href="<?php echo e(asset('plugins/datatable/css/buttons.dataTables.min.css')); ?>" rel="stylesheet" />
        <?php $__env->stopPush(); ?>
        <?php $__env->startPush('js'); ?>
            <script src="<?php echo e(asset('plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/dataTables.responsive.min.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/jszip.min.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/pdfmake.min.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/vfs_fonts.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/buttons.html5.min.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/buttons.print.min.js')); ?>"></script>
            <script src="<?php echo e(asset('plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php if(isset($filepond) and $filepond==true): ?>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('plugins/filepond/filepond.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('plugins/filepond/filepond-plugin-image-preview.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('plugins/filepond/filepond-plugin-image-preview.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/filepond/filepond.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php if(isset($ckeditor) and $ckeditor==true): ?>
    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('plugins/ckeditor/ckeditor.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php if(isset($sweetalert) and $sweetalert): ?>
    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('plugins/sweetalert/sweetalert.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH D:\projects\my_works\resources\views/inc/scripts.blade.php ENDPATH**/ ?>