<div x-data="" x-init="
    setTimeout(()=>{
        swal({
            icon: '<?php echo e($icon??'info'); ?>',
            title: '<?php echo e($title??'Are you sure'); ?>',
            text: '<?php echo e($text??'Once deleted recovery is not possible'); ?>',
            buttons: true,
        }).then((result)=>{
            if(result){
                window.livewire.find('<?php echo e($_instance->id); ?>').<?php echo e($deleteAction); ?>()
            }else{
                window.livewire.find('<?php echo e($_instance->id); ?>').<?php echo e($closeAction); ?>

            }
        });
    },100);
"></div>
<?php /**PATH D:\projects\my_works\resources\views/components/confirmation.blade.php ENDPATH**/ ?>